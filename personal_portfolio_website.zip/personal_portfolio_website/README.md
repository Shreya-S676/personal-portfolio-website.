# Personal Portfolio Website

A beginner-friendly, responsive portfolio website made with HTML, CSS, and JavaScript.

## Project overview
This site introduces its owner, presents skills and sample projects, and provides contact information.

## Features
- Responsive layout for desktop and mobile
- Navigation menu that collapses on small screens
- About, skills, projects, and contact sections
- Interactive contact-details button
- Back-to-top button
- Current year in the footer

## Technology stack
- HTML5
- CSS3
- Vanilla JavaScript

## How to run locally
1. Download or clone this repository.
2. Open the project folder.
3. Open `index.html` in a web browser.

No backend, database, or package installation is required.

## Customization
1. Replace `Your Name` with your name in `index.html`.
2. Update the introduction, skills, and project descriptions.
3. Replace `your.email@example.com` with an email address you want to publish.
4. Replace the GitHub profile link with your own profile URL.
5. Optionally replace the initials placeholder with a photo you have permission to use.

## Deployment using GitHub Pages
1. Create a GitHub repository named `personal-portfolio-website`.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository's root.
3. Open the repository's **Settings**.
4. Select **Pages** in the left sidebar.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Choose the `main` branch and `/(root)` folder, then save.
7. Wait for deployment to finish. GitHub Pages will show the live website URL on the Pages settings screen.

## Submission
Submit:
- GitHub repository URL
- Live GitHub Pages website URL

## Note
Replace all placeholder text and test your website before submitting. Do not publish private contact information.
